libimobiledevice Windows 编译产物
================================

编译时间: Thu Dec 11 19:45:44 CST 2025
编译环境: MINGW64
编译器: gcc.exe (Rev8, Built by MSYS2 project) 15.2.0

目录结构:
---------
./           - 可执行文件和 DLL 文件（根目录）
lib/         - 静态库和导入库
include/     - 头文件
pkgconfig/   - pkg-config 文件

使用说明:
---------
1. 将此目录添加到系统 PATH 环境变量
2. 或者直接从此目录运行工具

可用工具:
---------
afcclient.exe
idevice_id.exe
idevicebackup.exe
idevicebackup2.exe
idevicebtlogger.exe
idevicecrashreport.exe
idevicedate.exe
idevicedebug.exe
idevicedebugserverproxy.exe
idevicedevmodectl.exe
idevicediagnostics.exe
ideviceenterrecovery.exe
ideviceimagemounter.exe
ideviceinfo.exe
idevicename.exe
idevicenotificationproxy.exe
idevicepair.exe
ideviceprovision.exe
idevicescreenshot.exe
idevicesetlocation.exe
idevicesyslog.exe

依赖的 DLL:
-----------
libbrotlicommon.dll
libbrotlidec.dll
libbrotlienc.dll
libcrypto-3-x64.dll
libcurl-4.dll
libgcc_s_seh-1.dll
libiconv-2.dll
libidn2-0.dll
libimobiledevice-1.0.dll
libimobiledevice-glue-1.0.dll
libintl-8.dll
libnghttp2-14.dll
libplist++-2.0.dll
libplist-2.0.dll
libpsl-5.dll
libssh2-1.dll
libssl-3-x64.dll
libstdc++-6.dll
libtatsu.dll
libunistring-5.dll
libusbmuxd-2.0.dll
libwinpthread-1.dll
zlib1.dll

